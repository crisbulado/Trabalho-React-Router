import usuarios from "./usuarios.json";

const LOCAL_STORAGE_KEY = 'loginData';

// Busca todos os usuarios
export const getUsuarios = () => {
  return usuarios;
};

// Salva usuário
export const setUsuario = (usuario) => {
  localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(usuario));
}

// Pega o usuário atual
export const getUsuario = () => {
  if (!localStorage.getItem(LOCAL_STORAGE_KEY)) {
    return null;
  }
  return JSON.parse(localStorage.getItem(LOCAL_STORAGE_KEY));
}

// Remove usuário
export const deleteUsuario = () => {
  localStorage.removeItem(LOCAL_STORAGE_KEY);
}
