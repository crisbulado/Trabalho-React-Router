import { createContext, useState, useContext, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { deleteUsuario, getUsuario, getUsuarios, setUsuario } from "./../data/loginService";

// Cria o contexto
const AuthContext = createContext();

// Provedor que envolverá a aplicação
export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const navigate = useNavigate();

  // Continuar logado pelo local storage
  const verSeUsuarioLogado = () => {
    const usuario = getUsuario();
    if (usuario) {
      setUser(usuario);
      navigate('/admin/lista')
    }
  }

  useEffect(() => {
    verSeUsuarioLogado();
  }, [])

  // Login
  const login = (email, password) => {
    const usuarios = getUsuarios()
    const usuario = usuarios.find(
      user => user.email === email && user.senha === password
    );
    
    if (usuario) {
      setUser(usuario);
      setUsuario(usuario);
      navigate("/admin");
    } else {
      alert("Credenciais inválidas!");
    }
  };

  // Logout
  const logout = () => {
    setUser(null);
    deleteUsuario();
    navigate("/login");
  };

  return (
    <AuthContext.Provider value={{ user, login, logout, verSeUsuarioLogado }}>
      {children}
    </AuthContext.Provider>
  );
};

// Hook personalizado para usar o contexto
export const useAuth = () => {
  return useContext(AuthContext);
};