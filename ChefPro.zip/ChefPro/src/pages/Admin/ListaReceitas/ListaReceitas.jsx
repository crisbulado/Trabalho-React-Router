import { Link, useNavigate } from 'react-router-dom';
import '../../Receitas/Receitas.css';
import { deleteReceita, getReceitas } from './../../../data/receitasService';
import './ListaReceitas.css';
export default function ListaReceitas() {
  const navigate = useNavigate();
  const receitas = getReceitas();

  const handleExcluir = (id) => {
    if (window.confirm('Tem certeza que deseja excluir esta receita?')) {
      deleteReceita(id);
      navigate("/admin/lista");
    }
  };

  return (
    <div className="receitas-container">
      <div className="receitas-header">
        <h2>Gerenciar Receitas</h2>
        <Link to="/admin/nova" className="ver-receita-btn">
          + Nova Receita
        </Link>
      </div>
      
      <div className="receitas-grid">
        {receitas.map(receita => (
          <div key={receita.id} className="receita-card">
            <h3>{receita.nome}</h3>
            <p>Por: {receita.autor}</p>
            <p>Tempo: {receita.tempo_total}</p>
            
            <div className="receita-actions">
              <Link to={`/receita/${receita.id}`} className="ver-receita-btn">
                Visualizar
              </Link>
              <Link 
                to={`/admin/editar/${receita.id}`} 
                className="ver-receita-btn editar-btn"
              >
                Editar
              </Link>
              <button 
                onClick={() => handleExcluir(receita.id)} 
                className="ver-receita-btn excluir-btn"
              >
                Excluir
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}